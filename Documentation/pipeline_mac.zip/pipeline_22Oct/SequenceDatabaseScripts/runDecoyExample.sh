perl create_fasta_for_searchEngine.pl  ~/Ritesh_Work/Toxo/ToxoDB/TgondiiME49_ToxoDB-6_2.fasta 3 ~/Ritesh_Work/Toxo/ToxoDB/TgondiiME49_ToxoDB-6_2_withdecoy.fasta

rm *.fasta

echo '****** Run formatdb/makeblastdb now ********'
