perl create_fasta_for_searchEngine.pl /home/ritesh/ToxoDB/TgondiiME49AnnotatedProteins_ToxoDB-6.2.fasta 3 /home/ritesh/ToxoDB/TgondiiME49_withdecoy.fasta

rm *.fasta

echo '****** Run formatdb now ********'
